package com.example.myapplication.search;


import com.example.myapplication.search.BTree.BTree;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SearchEngine {

    private static final String HASHTAG_REGEX = "#[a-zA-Z]+\\b";
    private static final int ORDER = 20;


    BTree<TagPostObj> tagTree;
    List<PostObj> postObjs;

    public SearchEngine(String jsonString) {
        postObjs = extractPostObj(jsonString);
        tagTree = extractTagPostObj(postObjs);
    }

    public List<PostObj> extractPostObj(String jsonString) {

        List<PostObj> postObjs = new ArrayList<PostObj>();
        try {
            JSONObject json = new JSONObject(jsonString);
            JSONArray posts = (JSONArray) json.get("allpost");

            for (int i = 0; i < posts.length(); i++) {
                JSONObject post = (JSONObject) posts.get(i);
                String image_url = post.getString("img_url");
                int comment_count = post.getInt("comment_count");
                int like_count = post.getInt("like_count");
                String text = post.getString("text");
                PostObj postObj = new PostObj(image_url, comment_count, like_count, text);
                postObjs.add(postObj);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return postObjs;
    }


    public BTree<TagPostObj> extractTagPostObj(List<PostObj> postObjs) {
        Pattern pattern = Pattern.compile(HASHTAG_REGEX);
        BTree<TagPostObj> bTree = new BTree<>(ORDER);
        for (PostObj postObj : postObjs) {
            List<String> tags = new ArrayList<String>();
            boolean matchFound = true;
            String textString = postObj.text;
            while (matchFound && !textString.equals("")) {
                Matcher matcher = pattern.matcher(textString);
                matchFound = matcher.find();
                if (matchFound) {
                    String hashTag = matcher.group(0);
                    tags.add(hashTag);
                    textString = textString.substring(matcher.end());
                }
            }
            if (tags.size() != 0) {
                for (String tag : tags) {
                    bTree.insert(new TagPostObj(postObj, tag));
                }
            } else {
                bTree.insert(new TagPostObj(postObj, "NoTag"));
            }
        }
        return bTree;
    }

    public Object queryTag(String tag) {
        List<String> returnedString = new ArrayList<>();
        List<TagPostObj> tagPostObjs = this.tagTree.get(new TagPostObj(null ,tag));
        for(TagPostObj tagPostObj : tagPostObjs) {
            returnedString.add(tagPostObj.postObj.text);
        }
        return returnedString;
    }

    public String queryMinTag() {
        return this.tagTree.min().tag;
    }

    public String queryMaxTag() {
        return this.tagTree.max().tag;
    }

    public int getNumPosts() {
        return this.postObjs.size();
    }
}




