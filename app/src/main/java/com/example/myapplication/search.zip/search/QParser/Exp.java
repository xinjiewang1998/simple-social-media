package com.example.myapplication.search.QParser;

public abstract class Exp {

    public String show() {
        return null;
    }

    public int evaluate() {
        return 0;
    }
}
