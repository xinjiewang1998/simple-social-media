package com.example.myapplication.search;

public class TagPostObj implements Comparable<TagPostObj> {

    PostObj postObj;
    String tag;

    public TagPostObj(PostObj postObj, String tag) {
        this.postObj = postObj;
        this.tag = tag;
    }

    @Override
    public int compareTo(TagPostObj tagPostObj) {
        return this.tag.compareTo(tagPostObj.tag);
    }
}