package com.example.myapplication.search.QParser;

public class NotExp extends Exp {
    @Override
    public String show() {
        return null;
    }

    @Override
    public int evaluate() {
        return 0;
    }
}
